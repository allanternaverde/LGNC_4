# LGNC_4
Código principais: alunagem.m; ativ4.m.
