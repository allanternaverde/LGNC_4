% alunagem
clear all;
close all;
clc;

%% dados de entrada
% tracao do jato [desligado ligado]
E = [0 2.5];
% gravidade lunar
g = -1.5;
% massa do veiculo espacial
M = 1;
% condicoes de velocidade inicial para o grafico
v0 = [-20:0.1:0];
% valores de theta(inclinacao da propulsao) possíveis
theta = deg2rad([0 35]);
% vetore com as aceleracoes permitidas dado os angulos theta considerando
% os propulsores ligados
a = E(2)*cos(theta)/M+g;

% condicoes de pouso suave
v_f = 0;
y_f = 0;

% condicoes inicias de velocidade e altura
v_0 = -14;
y_0 = 150;


%% curvas de pouso suave
% torricelli com condiçoes finais zeros e jato a 0 graus
y0(:,1) = v0.^2/(2*a(1));
% torricellli com condições finais zeros e jato a 35 graus
y0(:,2) = v0.^2/(2*a(2));

% figura com condicoes de pouso suave
figure();
hold on; grid minor;

% plot das curvas de pouso suave
plot(v0,y0(:,1),'Linewidth', 2, 'DisplayName', [num2str(rad2deg(theta(1))),'�']);
plot(v0,y0(:,2),'Linewidth', 2, 'DisplayName',[num2str(rad2deg(theta(2))),'�']);
ylabel('y_0');
xlabel('v_0');
legend('show');


%% condicoes iniciais do problema
%plot das condicoes inicias
scatter(v_0,y_0,'filled','Linewidth', 2, 'MarkerEdgeColor','k', 'DisplayName','Cond. iniciais');
legend('off');
legend('show');

%% condicao de chavemento queda-livre -> 0°
E = [0 2.5];
theta = [0 0];
% aceleracao antes do chaveamento
a1 =  E(1)*cos(deg2rad(theta(1)))/M+g;
% aceleracao depois do chaveamento
a2 =  E(2)*cos(deg2rad(theta(2)))/M+g;

% calcula o ponto de chaveamento
%valores de codicoes iniciais e finais e aceleracoes antes e apos chaveamento
vals = [v_0, y_0, v_f, y_f, a1, a2];
[y(1), v(1), t(:,1), traj(:,1)] = ptoChaveamento(vals);

% plota o pronto de chaveamento
scatter(v(1), y(1), 'filled','Linewidth', 2, 'MarkerEdgeColor','k', ...
    'DisplayName','queda -> 0�');
legend('off');
legend('show');

%% condicao de chavemento 0° -> 35°
E = [2.5 2.5];
theta = [0 35];
% aceleracao antes do chaveamento
a1 =  E(1)*cos(deg2rad(theta(1)))/M+g;
% aceleracao depois do chaveamento
a2 = E(2)*cos(deg2rad(theta(2)))/M+g;

vals = [v_0, y_0, v_f, y_f, a1, a2];
[y(2), v(2), t(:,2), traj(:,2)] = ptoChaveamento(vals);

% plota o pronto de chaveamento
scatter(v(2), y(:,2), 'filled','Linewidth', 2, 'MarkerEdgeColor','k', ...
    'DisplayName','0� -> 35�');
legend('off');
legend('show');

%% condicao de chavemento 35° -> 0°
E = [2.5 2.5];
theta = [35 0];
% aceleracao antes do chaveamento
a1 =  E(1)*cos(deg2rad(theta(1)))/M+g;
% aceleracao depois do chaveamento
a2 = E(2)*cos(deg2rad(theta(2)))/M+g;

vals = [v_0, y_0, v_f, y_f, a1, a2];
[y(3), v(3), t(:,3), traj(:,3)] = ptoChaveamento(vals);

% plota o pronto de chaveamento
scatter(v(3), y(:,3), 'filled','Linewidth', 2, 'MarkerEdgeColor','k', ...
    'DisplayName','35� -> 0�');
legend('off');
legend('show');


%% tabelo com tempos ate primeiro chaveamento
disp('Tempos até o primeiro chaveamento:');
disp(t(1,:));

disp('Tempo total até o pouso:');
disp(t(1,:)+t(2,:));

%% plot das trajetórias
% figure();
% hold on;
% grid minor;
% leg = {};

% %% pontos de chaveamento
% scatter(v_0,y_0,'filled','Linewidth', 2, 'MarkerEdgeColor','k');
% scatter(-v_1(1),y_1(1),'filled','Linewidth', 2, 'MarkerEdgeColor','k');
% scatter(-v_2(1),y_2(1),'filled','Linewidth', 2, 'MarkerEdgeColor','k');
% scatter(-v_3(1),y_3(1),'filled','Linewidth', 2, 'MarkerEdgeColor','k');
% plot(v0,y0,'Linewidth', 0.1)

%% trajetoria em queda livre a partir da posicao inicial
plot(traj(1,1).v, traj(1,1).y, 'Linewidth', 2, 'LineStyle', '-.', 'Color','g');
% trajetoria com acionamento a 0 graus apos queda livre
plot(traj(2,1).v, traj(2,1).y, 'Linewidth', 2, 'LineStyle', '-.', 'Color','g');

%% trajetoria com acionamento a 0 graus a partir da posição inicial
plot(traj(1,2).v, traj(1,2).y, 'Linewidth', 2, 'LineStyle', '-.', 'Color','m');
% trajetoria com acionamento a 35 graus apos jato a 0 graus
plot(traj(2,2).v, traj(2,2).y, 'Linewidth', 2, 'LineStyle', '-.', 'Color','m');

%% trajetoria com acionamento a 35 graus a partir da posição inicial
plot(traj(1,3).v, traj(1,3).y, 'Linewidth', 2, 'LineStyle', '-.', 'Color','b');
% trajetoria com acionamento a 0 graus apos jato a 35 graus
ln3 = plot(traj(2,3).v, traj(2,3).y, 'Linewidth', 2, 'LineStyle', '-.', 'Color','b');
% 
% 
% lines = [ln1 ln2 ln3];
% legds = {'1.3832s + 16.0748s = 17.458s',...
%         '2.7738s + 20.4902s = 23.264s',...
%         '10.2852s + 8.365s = 18.6501s'};
%     
% %legend(lines, legds);
% xlabel('v_0');
% ylabel('y_0');
% 
% 
% %% Estrat�gia 3 - Propulsor a 35� + Propulsor a -35� + Propulsor a 0� (garante pouso suave em x e y)
% m = M;
% theta = 35*pi/180;
% y_inicial = 150;
% y_linha_inicial = -14;
% x_inicial = 0;
% x_linha_inicial = 0;
% 
% y_1 = ((y_linha_inicial^2) - (2*((E*cos(theta)/m) + g)*y_inicial))/(2*(E/m)*(1 - cos(theta)));
% passo = floor((y_inicial-y_1)/0.001);
% passo_1 = floor(y_1/0.001);
% 
% for i = 1:(passo+1)
%     y(i) = y_inicial - (0.001*(i-1));
%     y_linha1(i) = -sqrt(((y_linha_inicial)^2) + (2*((E*cos(theta)/m) + g)*(y(i) - y_inicial)));
%     x_linha1(i) = x_linha_inicial + ((y_linha1(i) - y_linha_inicial)*(E*sin(theta)/m)/((E*cos(theta)/m) + g));
% end
% 
% for i = (passo+1):(passo + passo_1 + 2)
%     y(i) = y_inicial - (0.001*(i-1));
%     y_linha1(i) = -sqrt(((y_linha1(passo + 1))^2) + (2*((E/m) + g)*(y(i) - y(passo + 1))));
%     x_linha1(i) = x_linha1(passo+1) + ((y_linha1(i) - y_linha1(passo+1))*(E*sin(0)/m)/((E*cos(0)/m) + g));
% end
% 
% figure();
% hold on;
% plot(x_linha1,y,'Linewidth', 2, 'LineStyle', '-.', 'Color','b')
% grid minor;
% ylabel('y [m]')
% xlabel('v_x[m/s]')
% 
% y_2 = y_1;
% v_1 = (y_linha_inicial + y_linha1(passo + 1))/2;
% y_1 = (-(y_linha_inicial^2) + ((v_1)^2) + (2*((E*cos(theta)/m) + g)*y_inicial))/(2*((E*cos(theta)/m) + g));
% 
% clear y
% clear y_linha1
% 
% passo1 = floor((y_inicial - y_1)/0.001);
% passo2 = floor((y_1 - y_2)/0.001);
% passo3 = floor(y_2/0.001);
% 
% for i = 1:(passo1+1)
%     y(i) = y_inicial - (0.001*(i-1));
%     y_linha1(i) = -sqrt(((y_linha_inicial)^2) + (2*((E*cos(theta)/m) + g)*(y(i) - y_inicial)));
%     x_linha1(i) = x_linha_inicial + (((y_linha1(i) - y_linha_inicial)*(E*sin(theta)/m))/((E*cos(theta)/m) + g));
% end
% 
% for i = (passo1 + 1):(passo1 + passo2 + 2)
%     y(i) = y_inicial - (0.001*(i-1));
%     y_linha1(i) = -sqrt(((y_linha1(passo1 + 1))^2) + (2*((E*cos(-theta)/m) + g)*(y(i) - y(passo1 + 1))));
%     x_linha1(i) = x_linha1(passo1 + 1) + ((y_linha1(i) - y_linha1(passo1 + 1))*(E*sin(-theta)/m)/((E*cos(-theta)/m) + g));
% end
% 
% for i = (passo1 + passo2 + 2):(passo1 + passo2 + passo3 + 3)
%     y(i) = y_inicial - (0.001*(i-1));
%     y_linha1(i) = -sqrt(((y_linha1(passo1 + passo2 + 2))^2) + (2*((E/m) + g)*(y(i) - y(passo1 + passo2 + 2))));
%     x_linha1(i) = x_linha1(passo1 + passo2 + 2) + ((y_linha1(i) - y_linha1(passo1 + passo2 + 2))*(E*sin(0)/m)/((E*cos(0)/m) + g));
% end
% 
% figure();
% hold on;
% plot(x_linha1,y,'Linewidth', 2, 'LineStyle', '-.', 'Color','b')
% grid minor;
% ylabel('y [m]')
% xlabel('v_x [m/s]')
% 
