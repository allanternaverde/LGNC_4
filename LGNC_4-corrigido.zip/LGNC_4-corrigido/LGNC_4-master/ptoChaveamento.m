function [y_1, v_1, t, traj]= ptoChaveamento(vals)
% vals = [v_0, y_0, v_f, y_f, a1, a2];
% calcula o ponto de chaveamento
syms v_1 y_1 v_0 y_0 v_2 y_2 a1 a2;
vars = [v_0, y_0, v_2, y_2, a1, a2];

[y_1, v_1] = solve(v_1^2 == v_0^2 + 2*a1*(y_1 - y_0), v_2^2 == v_1^2 + 2*a2*(y_2 - y_1), 'y_1','v_1');

y_1 = double(vpa(subs(y_1, vars, vals)));
v_1 = double(vpa(subs(v_1, vars, vals)));

y_1 = abs(y_1(1));
v_1 = -abs(v_1(1));


t(1) = abs((v_1 - vals(1))/vals(5));
t(2) = abs((vals(3) - abs(v_1))/vals(6));

%% trajetoria em queda livre a partir da posicao inicial
traj(1) = trajetoria(vals(5), vals(1), vals(2), t(1));
traj(2) = trajetoria(vals(6), v_1, y_1, t(2));

end